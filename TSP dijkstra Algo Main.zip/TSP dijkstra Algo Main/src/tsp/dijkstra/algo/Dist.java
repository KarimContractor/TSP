/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package tsp.dijkstra.algo;

/**
 *
 * @author contr
 */
public class Dist {
    public int ID;
    public int PointID;
    public int ConnectsID;
    public double Distance;

    Dist() {
        //throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }   
    
    //public int getID(){return ID;}
   // public void setID(int id){ID=id;}
    
    //public int getpoint(){return PointID;}
   // public void setpoint(int point){PointID=point;}
    
   // public int getcon(){return ConnectsID;}
   // public void setcon(int con){ConnectsID=con;}

    //public double getdistance(){return Distance;}
    //public void setdistance(Double distance){Distance=distance;}

}
